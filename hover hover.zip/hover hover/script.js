const bodyEl = document.querySelector("body");

function throttle(fn, wait) {
    let time = Date.now();
    return function(event) {
        if ((time + wait - Date.now()) < 0) {
            fn(event);
            time = Date.now();
        }
    };
}

function createHeart(event) {
    const x = event.clientX;
    const y = event.clientY;
    const spanEl = document.createElement("span");
    spanEl.style.left = x + "px";
    spanEl.style.top = y + "px";
    const size = Math.random() * 50+70; // Ensure size is between 30 and 50
    spanEl.style.width = size + "px";
    spanEl.style.height = size + "px";
    spanEl.style.position = "absolute";
    spanEl.style.transform = "translate(-50%, -50%)"; // Center the heart
    bodyEl.appendChild(spanEl);
    setTimeout(() => {
        spanEl.remove();
    }, 2000); // Match the animation duration
}

window.addEventListener("mousemove", throttle(createHeart, 100)); // Adjust the wait time as needed